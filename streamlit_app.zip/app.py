import streamlit as st
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OrdinalEncoder, LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (confusion_matrix, accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, roc_curve)
import plotly.express as px
import plotly.graph_objects as go
import matplotlib.pyplot as plt
import io
import base64

st.set_page_config(page_title="Attrition Dashboard", layout="wide")

st.title("Employee Attrition — HR Insights & Predictive Toolkit")

@st.cache_data
def load_data(uploaded_file):
    if uploaded_file is not None:
        df = pd.read_csv(uploaded_file)
    else:
        st.info("Please upload a CSV file in the 'Data' tab to start. The app can work with any CSV but expects a binary target column (e.g., 'Attrition') for modeling.")
        df = pd.DataFrame()
    return df

def auto_detect_target(df):
    # Try common names
    candidates = ['Attrition', 'attrition', 'LEFT', 'Left', 'status', 'Status', 'POLICY_STATUS', 'policy_status']
    for c in candidates:
        if c in df.columns:
            return c
    # else find any column with <=2 unique non-null values
    for c in df.columns:
        if df[c].nunique(dropna=True) <= 2:
            return c
    return None

def preprocess_for_model(df, target_col):
    df2 = df.copy()
    # Drop identifier-like columns
    id_like = [c for c in df2.columns if any(key in c.lower() for key in ['id','id_no','policy_no','no.','number'])]
    df2 = df2.drop(columns=[c for c in id_like if c in df2.columns], errors='ignore')
    # Keep only columns without too many uniques for categorical treatment
    X = df2.drop(columns=[target_col])
    y = df2[target_col]
    # Basic encoding of target to binary
    le = LabelEncoder()
    y_enc = le.fit_transform(y.astype(str))
    numeric_cols = X.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = X.select_dtypes(exclude=[np.number]).columns.tolist()
    # Build preprocessor
    numeric_transformer = SimpleImputer(strategy='median')
    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('ordinal', OrdinalEncoder(handle_unknown='use_encoded_value', unknown_value=-1))
    ])
    preprocessor = ColumnTransformer(transformers=[
        ('num', numeric_transformer, numeric_cols),
        ('cat', categorical_transformer, categorical_cols)
    ], remainder='drop')
    return X, y_enc, le, preprocessor, numeric_cols, categorical_cols

def train_and_evaluate(X, y, preprocessor, chosen_models):
    results = {}
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    for name in chosen_models:
        if name == 'Decision Tree':
            clf = DecisionTreeClassifier(random_state=42)
        elif name == 'Random Forest':
            clf = RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1)
        elif name == 'Gradient Boosting':
            clf = GradientBoostingClassifier(random_state=42)
        pipe = Pipeline(steps=[('pre', preprocessor), ('clf', clf)])
        # cross-validated predictions on training for confusion
        y_train_pred_cv = cross_val_predict(pipe, X, y, cv=cv, method='predict', n_jobs=-1)
        pipe.fit(X, y)
        # store
        results[name] = {'pipeline': pipe, 'y_train_pred_cv': y_train_pred_cv}
    return results

def plot_confusion_matrix(cm, labels, title):
    fig = go.Figure(data=go.Heatmap(
        z=cm,
        x=labels,
        y=labels,
        hoverongaps=False,
        colorscale='Blues',
        text=cm,
        texttemplate="%{text}",
    ))
    fig.update_layout(title=title, xaxis_title="Predicted", yaxis_title="Actual", width=500, height=400)
    return fig

def compute_test_metrics(pipe, X_test, y_test):
    y_pred = pipe.predict(X_test)
    if hasattr(pipe.named_steps['clf'], "predict_proba"):
        y_proba = pipe.predict_proba(X_test)[:, 1]
    else:
        try:
            dec = pipe.decision_function(X_test)
            y_proba = (dec - dec.min())/(dec.max()-dec.min())
        except Exception:
            y_proba = None
    metrics = {}
    metrics['accuracy'] = accuracy_score(y_test, y_pred)
    metrics['precision'] = precision_score(y_test, y_pred, zero_division=0)
    metrics['recall'] = recall_score(y_test, y_pred, zero_division=0)
    metrics['f1'] = f1_score(y_test, y_pred, zero_division=0)
    metrics['auc'] = roc_auc_score(y_test, y_proba) if y_proba is not None else np.nan
    metrics['y_pred'] = y_pred
    metrics['y_proba'] = y_proba
    metrics['cm'] = confusion_matrix(y_test, y_pred)
    return metrics

def df_to_download_link(df, filename="predictions.csv"):
    csv = df.to_csv(index=False)
    b64 = base64.b64encode(csv.encode()).decode()
    href = f"data:file/csv;base64,{b64}"
    return href

# --- Streamlit UI ---
st.sidebar.header("Data")
uploaded = st.sidebar.file_uploader("Upload CSV file with employee data", type=['csv'])

df = load_data(uploaded)

tab = st.tabs(["Data", "Dashboards", "Modeling", "Predict"])

with tab[0]:
    st.header("Data: preview and options")
    if df.empty:
        st.info("No data loaded yet. Upload a CSV in the sidebar (left).")
    else:
        st.write("Dataset shape:", df.shape)
        st.dataframe(df.head(200))
        st.markdown("**Auto-detected target (if any):**")
        detected = auto_detect_target(df)
        st.write(detected)
        st.markdown("If the detected target is not correct, choose the correct target below.")
        target_col = st.selectbox("Select target column (binary)", options=[None] + df.columns.tolist(), index=(0 if detected is None else df.columns.get_loc(detected)+1))
        if 'target_col' not in st.session_state:
            st.session_state['target_col'] = target_col
        else:
            st.session_state['target_col'] = target_col

with tab[1]:
    st.header("HR Dashboards — 5 Actionable Insights")
    if df.empty:
        st.info("Upload data to view dashboards.")
    else:
        # allow user to choose job role column and satisfaction column
        st.sidebar.header("Filters for Dashboards")
        job_role_col = st.sidebar.selectbox("Select Job Role column (for filtering)", options=[None] + df.columns.tolist(), index=1 if 'PI_OCCUPATION' in df.columns else 0)
        satisfaction_col = st.sidebar.selectbox("Select Satisfaction/NPS column (numeric)", options=[None] + df.columns.tolist())
        # multi-select roles
        roles = df[job_role_col].unique().tolist() if job_role_col and job_role_col in df.columns else []
        selected_roles = st.sidebar.multiselect("Filter Job Roles (multi-select applies to all charts)", options=roles, default=roles[:5] if roles else [])
        # satisfaction slider if numeric
        if satisfaction_col and np.issubdtype(df[satisfaction_col].dtype, np.number):
            minv = float(df[satisfaction_col].min())
            maxv = float(df[satisfaction_col].max())
            sat_range = st.sidebar.slider("Satisfaction range", min_value=minv, max_value=maxv, value=(minv, maxv))
        else:
            sat_range = None

        # apply filters
        dff = df.copy()
        if job_role_col and selected_roles:
            dff = dff[dff[job_role_col].isin(selected_roles)]
        if satisfaction_col and sat_range is not None:
            dff = dff[(dff[satisfaction_col] >= sat_range[0]) & (dff[satisfaction_col] <= sat_range[1])]

        # Chart 1: Attrition rate by job role (bar) with baseline and change
        st.subheader("1) Attrition rate by Job Role (sorted)")
        if job_role_col and 'target_col' in st.session_state and st.session_state['target_col']:
            tmp = dff[[job_role_col, st.session_state['target_col']]].dropna()
            rates = tmp.groupby(job_role_col)[st.session_state['target_col']].apply(lambda x: (x.astype(str)=='1').mean() if x.dtype.name!='category' else (x=='Yes').mean()).reset_index(name='attrition_rate')
            rates = rates.sort_values('attrition_rate', ascending=False)
            fig1 = px.bar(rates, x=job_role_col, y='attrition_rate', title='Attrition rate by role', labels={'attrition_rate':'Attrition Rate'})
            st.plotly_chart(fig1, use_container_width=True)
        else:
            st.info("Select a target column in the Data tab for meaningful attrition charts.")

        # Chart 2: Salary vs Satisfaction scatter with trend and color by attrition
        st.subheader("2) Salary vs Satisfaction (scatter) — look for risk clusters")
        num_salary = None
        if any('income' in c.lower() for c in df.columns):
            candidates = [c for c in df.columns if 'income' in c.lower() or 'salary' in c.lower() or 'annual' in c.lower()]
            num_salary = candidates[0]
        if satisfaction_col and num_salary and satisfaction_col in dff.columns and num_salary in dff.columns:
            scatter_df = dff[[num_salary, satisfaction_col, st.session_state['target_col']]].dropna()
            scatter_df['attrition_flag'] = scatter_df[st.session_state['target_col']].astype(str)
            fig2 = px.scatter(scatter_df, x=num_salary, y=satisfaction_col, color='attrition_flag', marginal_x='box', marginal_y='violin', trendline='ols',
                              title=f"{num_salary} vs {satisfaction_col} colored by attrition")
            st.plotly_chart(fig2, use_container_width=True)
        else:
            st.info("Salary and satisfaction columns not both found. You can upload dataset with such columns or choose different columns in sidebar.")

        # Chart 3: Stacked bar attrition by Gender and Job Role
        st.subheader("3) Attrition by Gender & Job Role (stacked bars)")
        if 'PI_GENDER' in dff.columns and job_role_col and job_role_col in dff.columns and st.session_state.get('target_col'):
            tmp = dff[[job_role_col,'PI_GENDER', st.session_state['target_col']]].dropna()
            tmp['attr_flag'] = tmp[st.session_state['target_col']].astype(str)
            grp = tmp.groupby([job_role_col,'PI_GENDER','attr_flag']).size().reset_index(name='count')
            fig3 = px.bar(grp, x=job_role_col, y='count', color='attr_flag', facet_col='PI_GENDER', title='Attrition counts by role and gender')
            st.plotly_chart(fig3, use_container_width=True)
        else:
            st.info("Gender, job role, or target missing for this chart.")

        # Chart 4: Correlation heatmap for numeric features (highlight attrition correlation)
        st.subheader("4) Numeric Correlations — identify predictors correlated with attrition")
        num_cols = dff.select_dtypes(include=[np.number]).columns.tolist()
        if num_cols:
            corr = dff[num_cols].corr()
            fig4 = px.imshow(corr, text_auto=True, title='Correlation matrix (numeric features)')
            st.plotly_chart(fig4, use_container_width=True)
        else:
            st.info("No numeric columns found for correlation heatmap.")

        # Chart 5: Boxplots of salary (or numeric) by attrition
        st.subheader("5) Distribution of compensation/age by attrition (boxplots)")
        if num_salary and num_salary in dff.columns and st.session_state.get('target_col'):
            bp = dff[[num_salary, st.session_state['target_col']]].dropna()
            bp['attr_flag'] = bp[st.session_state['target_col']].astype(str)
            fig5 = px.box(bp, x='attr_flag', y=num_salary, points='all', title=f"{num_salary} distribution by attrition")
            st.plotly_chart(fig5, use_container_width=True)
        else:
            st.info("Salary or target column missing for boxplot.")

with tab[2]:
    st.header("Modeling — Train DT, RF, GBRT (stratified cv=5)")
    if df.empty:
        st.info("Upload data to the app to enable modeling.")
    else:
        if not st.session_state.get('target_col'):
            st.warning("Select a target column in the Data tab before training.")
        else:
            target_col = st.session_state['target_col']
            st.write("Target:", target_col)
            X, y_enc, le, preprocessor, numeric_cols, categorical_cols = preprocess_for_model(df, target_col)
            st.write("Features:", len(X.columns), "| Numeric:", len(numeric_cols), "| Categorical:", len(categorical_cols))
            cols_for_model = st.multiselect("Choose features to include (leave empty for all)", options=X.columns.tolist(), default=[])
            if cols_for_model:
                X = X[cols_for_model]
            # select models
            chosen = st.multiselect("Select algorithms to train", options=['Decision Tree','Random Forest','Gradient Boosting'], default=['Decision Tree','Random Forest','Gradient Boosting'])
            if st.button("Train models and evaluate (this may take time)"):
                with st.spinner("Training..."):
                    # train-test split
                    X_train, X_test, y_train, y_test = train_test_split(X, y_enc, test_size=0.2, random_state=42, stratify=y_enc)
                    results = train_and_evaluate(X_train, y_train, preprocessor, chosen)
                    # Evaluate on test set
                    metrics_table = []
                    roc_traces = []
                    for name, info in results.items():
                        pipe = info['pipeline']
                        metrics = compute_test_metrics(pipe, X_test, y_test)
                        metrics_table.append({
                            'Algorithm': name,
                            'Train Accuracy (cv pred)': accuracy_score(y_train, info['y_train_pred_cv']),
                            'Test Accuracy': metrics['accuracy'],
                            'Precision': metrics['precision'],
                            'Recall': metrics['recall'],
                            'F1': metrics['f1'],
                            'AUC': metrics['auc']
                        })
                        # confusion matrices
                        st.subheader(f"{name} - Training (CV predictions) confusion matrix")
                        cm1 = confusion_matrix(y_train, info['y_train_pred_cv'])
                        fig_cm1 = plot_confusion_matrix(cm1, labels=le.classes_.tolist(), title=f"{name} - Train (CV)")
                        st.plotly_chart(fig_cm1)
                        st.subheader(f"{name} - Test confusion matrix")
                        fig_cm2 = plot_confusion_matrix(metrics['cm'], labels=le.classes_.tolist(), title=f"{name} - Test")
                        st.plotly_chart(fig_cm2)
                        # ROC trace
                        if metrics['y_proba'] is not None:
                            fpr, tpr, _ = roc_curve(y_test, metrics['y_proba'])
                            roc_traces.append({'name': name, 'fpr':fpr, 'tpr':tpr, 'auc':metrics['auc']})
                        # feature importance
                        try:
                            fi = pipe.named_steps['clf'].feature_importances_
                            feat_names = numeric_cols + categorical_cols
                            fi_series = pd.Series(fi, index=feat_names).sort_values(ascending=False).head(20)
                            st.subheader(f"{name} - Top feature importances")
                            fig_fi = px.bar(fi_series[::-1], orientation='h', title=f"{name} feature importances (top 20)")
                            st.plotly_chart(fig_fi, use_container_width=True)
                        except Exception as e:
                            st.write("Feature importances not available for", name)
                    metrics_df = pd.DataFrame(metrics_table).set_index('Algorithm')
                    st.dataframe(metrics_df)
                    # Combined ROC
                    if roc_traces:
                        fig = go.Figure()
                        for tr in roc_traces:
                            fig.add_trace(go.Scatter(x=tr['fpr'], y=tr['tpr'], mode='lines', name=f"{tr['name']} (AUC={tr['auc']:.3f})"))
                        fig.add_trace(go.Scatter(x=[0,1], y=[0,1], mode='lines', name='Random', line=dict(dash='dash')))
                        fig.update_layout(title="ROC Curves (Test set)", xaxis_title="False Positive Rate", yaxis_title="True Positive Rate")
                        st.plotly_chart(fig, use_container_width=True)
                    # Save trained pipelines in session for predict tab
                    st.session_state['trained_pipelines'] = {name:info['pipeline'] for name,info in results.items()}

with tab[3]:
    st.header("Predict — Upload new data and generate predictions")
    if 'trained_pipelines' not in st.session_state:
        st.info("Train models first in the Modeling tab, then return here to make predictions. Alternatively, upload a dataset with a target column to test predictions.")
    else:
        uploaded_new = st.file_uploader("Upload new CSV for prediction (rows will be predicted)", type=['csv'])
        model_choice = st.selectbox("Choose model for prediction", options=list(st.session_state['trained_pipelines'].keys()))
        if uploaded_new and model_choice:
            new_df = pd.read_csv(uploaded_new)
            pipe = st.session_state['trained_pipelines'][model_choice]
            # Ensure same columns are present; pipe will drop unknown columns silently; for safety, select intersection
            X_new = new_df.copy()
            preds = pipe.predict(X_new)
            # try to get probability
            proba = None
            if hasattr(pipe.named_steps['clf'], "predict_proba"):
                proba = pipe.predict_proba(X_new)[:,1]
            new_df['Predicted_Attrition'] = preds
            if proba is not None:
                new_df['Pred_Prob'] = proba
            st.write("Sample predictions:")
            st.dataframe(new_df.head(200))
            # download link
            href = df_to_download_link(new_df, filename="predictions.csv")
            st.markdown(f"[Download predictions CSV]({href})")