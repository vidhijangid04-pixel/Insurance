Streamlit Dashboard for model training, evaluation and prediction
===============================================================

Files in this package:
- app.py : Main Streamlit application (single-file).
- requirements.txt : list of packages (no versions) to install in the Streamlit Cloud app.
- Insurance.csv : optional sample dataset (not included by default).

How to use:
1. Create a new GitHub repo and upload all files from this zip (no folders).
2. On Streamlit Cloud, create a new app connected to the GitHub repo and set the main file to `app.py`.
3. The app will allow CSV upload, show charts, train models (DT, RF, GBRT) with stratified 5-fold CV, and predict on new data.
