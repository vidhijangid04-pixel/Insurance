import streamlit as st
import pandas as pd
import numpy as np
import io
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OrdinalEncoder, LabelEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (confusion_matrix, accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve)
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from sklearn.preprocessing import label_binarize
import base64

st.set_page_config(layout="wide", page_title="HR / Policy Dashboard")

st.title("Streamlit Dashboard — Data, Modelling & Insights")
st.markdown("Upload your dataset (CSV). The app will try to detect target column `POLICY_STATUS` by default. If not present, choose target manually. "
            "This dashboard includes interactive charts, model training (DT, RF, GBRT) with stratified 5-fold CV, and prediction on new data.")

# Utilities
@st.cache_data
def load_csv(uploaded_file):
    return pd.read_csv(uploaded_file)

def detect_columns(df):
    cols = df.columns.tolist()
    cat_cols = df.select_dtypes(include=['object','category','bool']).columns.tolist()
    num_cols = df.select_dtypes(include=['number']).columns.tolist()
    return cols, cat_cols, num_cols

def preprocess_for_model(df, target_col):
    df = df.copy()
    # drop columns with >90% unique values (likely IDs/names)
    high_card = [c for c in df.columns if df[c].nunique(dropna=True)/len(df) > 0.9 and c!=target_col]
    df = df.drop(columns=high_card)
    # drop constant cols
    const_cols = [c for c in df.columns if df[c].nunique(dropna=True) <= 1 and c!=target_col]
    df = df.drop(columns=const_cols)
    X = df.drop(columns=[target_col])
    y = df[target_col].copy()
    # simple imputation and encoding
    numeric_cols = X.select_dtypes(include=['number']).columns.tolist()
    cat_cols = X.select_dtypes(include=['object','category','bool']).columns.tolist()
    numeric_transformer = Pipeline([('imp', SimpleImputer(strategy='median')), ('sc', StandardScaler())])
    cat_transformer = Pipeline([('imp', SimpleImputer(strategy='most_frequent')), ('enc', OrdinalEncoder(handle_unknown='use_encoded_value', unknown_value=-1))])
    preprocessor = ColumnTransformer([('num', numeric_transformer, numeric_cols), ('cat', cat_transformer, cat_cols)], remainder='drop')
    return preprocessor, X, y, numeric_cols, cat_cols

def train_and_evaluate(X, y, preprocessor, random_state=42):
    # encode target
    le = LabelEncoder()
    y_enc = le.fit_transform(y)
    class_names = le.classes_
    X_train, X_test, y_train, y_test = train_test_split(X, y_enc, test_size=0.3, random_state=random_state, stratify=y_enc)
    models = {
        'DecisionTree': DecisionTreeClassifier(random_state=random_state),
        'RandomForest': RandomForestClassifier(n_estimators=100, random_state=random_state),
        'GradientBoosting': GradientBoostingClassifier(n_estimators=100, random_state=random_state)
    }
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=random_state)
    results = {}
    for name, model in models.items():
        pipe = Pipeline([('pre', preprocessor), ('clf', model)])
        # CV out-of-fold predictions for training confusion
        y_train_pred_cv = cross_val_predict(pipe, X_train, y_train, cv=cv, method='predict', n_jobs=1)
        pipe.fit(X_train, y_train)
        y_test_pred = pipe.predict(X_test)
        y_test_proba = pipe.predict_proba(X_test)
        # metrics
        if len(class_names) == 2:
            prec = precision_score(y_test, y_test_pred, pos_label=1, zero_division=0)
            rec = recall_score(y_test, y_test_pred, pos_label=1, zero_division=0)
            f1 = f1_score(y_test, y_test_pred, pos_label=1, zero_division=0)
            auc = roc_auc_score(y_test, y_test_proba[:,1])
        else:
            prec = precision_score(y_test, y_test_pred, average='macro', zero_division=0)
            rec = recall_score(y_test, y_test_pred, average='macro', zero_division=0)
            f1 = f1_score(y_test, y_test_pred, average='macro', zero_division=0)
            y_test_bin = label_binarize(y_test, classes=np.arange(len(class_names)))
            auc = roc_auc_score(y_test_bin, y_test_proba, average='macro', multi_class='ovr')
        results[name] = {
            'pipeline': pipe,
            'y_train': y_train,
            'y_train_pred_cv': y_train_pred_cv,
            'X_test': X_test,
            'y_test': y_test,
            'y_test_pred': y_test_pred,
            'y_test_proba': y_test_proba,
            'metrics': {
                'train_acc_cv': accuracy_score(y_train, y_train_pred_cv),
                'test_acc': accuracy_score(y_test, y_test_pred),
                'precision': prec,
                'recall': rec,
                'f1': f1,
                'auc': auc
            },
            'class_names': class_names
        }
    return results, le

def plot_confusion(cm, class_names, title="Confusion Matrix", cmap='Blues'):
    fig, ax = plt.subplots(figsize=(4,3))
    sns.heatmap(cm, annot=True, fmt='d', cmap=cmap, xticklabels=class_names, yticklabels=class_names, ax=ax)
    ax.set_xlabel("Predicted"); ax.set_ylabel("Actual"); ax.set_title(title)
    st.pyplot(fig)

def plot_roc_multi(results):
    fig = go.Figure()
    for name, res in results.items():
        proba = res['y_test_proba']
        y_test = res['y_test']
        class_names = res['class_names']
        if len(class_names) == 2:
            fpr, tpr, _ = roc_curve(y_test, proba[:,1])
            auc_val = res['metrics']['auc']
            fig.add_trace(go.Scatter(x=fpr, y=tpr, mode='lines', name=f"{name} (AUC={auc_val:.3f})"))
        else:
            # macro-average approx
            y_test_bin = label_binarize(y_test, classes=np.arange(len(class_names)))
            fpr = np.linspace(0,1,100)
            tprs = []
            for i in range(len(class_names)):
                fpr_i, tpr_i, _ = roc_curve(y_test_bin[:,i], proba[:,i])
                tpr_interp = np.interp(fpr, fpr_i, tpr_i)
                tprs.append(tpr_interp)
            mean_tpr = np.mean(tprs, axis=0)
            auc_val = res['metrics']['auc']
            fig.add_trace(go.Scatter(x=fpr, y=mean_tpr, mode='lines', name=f"{name} (AUC={auc_val:.3f})"))
    fig.add_shape(type="line", x0=0, y0=0, x1=1, y1=1, line=dict(dash="dash"))
    fig.update_layout(title="ROC Curves (Test Set)", xaxis_title="False Positive Rate", yaxis_title="True Positive Rate")
    st.plotly_chart(fig, use_container_width=True)

def get_feature_importances(results, feature_names):
    fi = {}
    for name, res in results.items():
        model = res['pipeline'].named_steps['clf']
        try:
            importances = model.feature_importances_
            fi[name] = pd.Series(importances, index=feature_names).sort_values(ascending=False)
        except Exception:
            fi[name] = None
    return fi

def download_link(df, filename="predictions.csv"):
    csv = df.to_csv(index=False)
    b64 = base64.b64encode(csv.encode()).decode()
    href = f'<a href="data:file/csv;base64,{b64}" download="{filename}">Download CSV file</a>'
    return href

# Sidebar: Upload or use example
st.sidebar.header("Data source")
uploaded = st.sidebar.file_uploader("Upload CSV file", type=['csv'])
use_sample = False
if uploaded is None:
    st.sidebar.info("No file uploaded. Using sample uploaded dataset if present in repo.")
    # try to load a sample CSV shipped with app
    try:
        sample = pd.read_csv("Insurance.csv")
        df = sample.copy()
        use_sample = True
    except Exception:
        st.sidebar.warning("No sample found. Please upload a CSV file.")
        df = None
else:
    df = load_csv(uploaded)

if df is None:
    st.stop()

cols, cat_cols, num_cols = detect_columns(df)
st.sidebar.markdown(f"**Columns detected:** {len(cols)} (Categorical: {len(cat_cols)}, Numeric: {len(num_cols)})")

# Target column selection
default_target = "POLICY_STATUS" if "POLICY_STATUS" in df.columns else cols[-1]
target_col = st.sidebar.selectbox("Select target column", options=cols, index=cols.index(default_target))
st.sidebar.markdown(f"Target: **{target_col}**")

# Choose role-like column for filters (user requested job role filter)
possible_roles = [c for c in cat_cols if c!=target_col]
role_col = st.sidebar.selectbox("Choose role/segment column (used as filter on charts)", options=possible_roles if possible_roles else cols, index=0)
# satisfaction-like slider numeric column
possible_sat = [c for c in num_cols if c!=target_col]
sat_col = st.sidebar.selectbox("Choose satisfaction/score numeric column (slider)", options=possible_sat if possible_sat else num_cols, index=0)

st.sidebar.markdown("---")
st.sidebar.header("Chart filters")
selected_roles = st.sidebar.multiselect(f"Filter by {role_col} (multi-select)", options=sorted(df[role_col].dropna().unique().tolist()), default=None)
sat_min, sat_max = None, None
if sat_col in df.columns and pd.api.types.is_numeric_dtype(df[sat_col]):
    minv, maxv = float(df[sat_col].min()), float(df[sat_col].max())
    sat_min, sat_max = st.sidebar.slider(f"{sat_col} range", min_value=minv, max_value=maxv, value=(minv, maxv))
else:
    st.sidebar.write("No numeric column available for slider.")

# Filtering dataset for charts
df_chart = df.copy()
if selected_roles:
    df_chart = df_chart[df_chart[role_col].isin(selected_roles)]
if sat_min is not None:
    df_chart = df_chart[df_chart[sat_col].between(sat_min, sat_max)]

# Layout: Tabs
tab1, tab2, tab3 = st.tabs(["Insights & Charts", "Train Models (DT/RF/GBRT)", "Predict New Data"])

with tab1:
    st.header("Charts & Insights")
    st.markdown("Five charts with actionable insights for HR/Policy decisions. Use filters on the left to refine the view.")
    # Chart 1: Attrition / Policy status distribution by role (stacked bar)
    if target_col in df_chart.columns:
        c1 = df_chart.groupby([role_col, target_col]).size().reset_index(name='count')
        fig1 = px.bar(c1, x=role_col, y='count', color=target_col, title=f"{target_col} count by {role_col}", barmode='stack')
        st.plotly_chart(fig1, use_container_width=True)
        st.markdown("**Insight:** Look for roles/segments with high proportion of 'Repudiate Death' to prioritize review and compliance.")
    else:
        st.info(f"Target column {target_col} not in data for Chart 1.")

    # Chart 2: Numerical distribution (satisfaction proxy) with target overlay - violin
    if sat_col in df_chart.columns and pd.api.types.is_numeric_dtype(df_chart[sat_col]):
        fig2 = px.violin(df_chart, x=target_col, y=sat_col, box=True, points='all', title=f"Distribution of {sat_col} by {target_col}")
        st.plotly_chart(fig2, use_container_width=True)
        st.markdown("**Insight:** Differences in distribution may indicate groups at risk (e.g., low satisfaction correlating with negative outcomes).")
    else:
        st.info("Satisfaction numerical column not found for Chart 2.")

    # Chart 3: Heatmap of correlations between numeric features and a binary-encoded target
    st.subheader("Correlation heatmap (numeric features vs target encoded)")
    numeric_cols = df_chart.select_dtypes(include=['number']).columns.tolist()
    if target_col in df_chart.columns and numeric_cols:
        df_corr = df_chart[numeric_cols].copy()
        try:
            df_corr[target_col] = LabelEncoder().fit_transform(df_chart[target_col])
            corr = df_corr.corr()
            fig3, ax = plt.subplots(figsize=(8,6))
            sns.heatmap(corr, annot=True, fmt=".2f", cmap='coolwarm', ax=ax)
            st.pyplot(fig3)
            st.markdown("**Insight:** Use this to identify numeric predictors most correlated with the target (positive or negative).")
        except Exception as e:
            st.write("Could not compute correlation heatmap:", e)
    else:
        st.info("Not enough numeric columns for heatmap.")

    # Chart 4: Top categories contributing to negative outcome (bar)
    st.subheader("Top categories linked to negative target outcome")
    if target_col in df_chart.columns:
        negative_label = df_chart[target_col].unique()[0] if len(df_chart[target_col].unique())==1 else df_chart[target_col].unique()[-1]
        # compute contribution ratio per role_col value
        grp = df_chart.groupby([role_col, target_col]).size().unstack(fill_value=0)
        if negative_label in grp.columns:
            grp['neg_ratio'] = grp[negative_label] / grp.sum(axis=1)
            top_neg = grp['neg_ratio'].sort_values(ascending=False).reset_index().head(10)
            fig4 = px.bar(top_neg, x=role_col, y='neg_ratio', title=f"Top {role_col} by proportion of '{negative_label}'")
            st.plotly_chart(fig4, use_container_width=True)
            st.markdown("**Insight:** Prioritize engagement/intervention for top segments with high negative outcome ratios.")
        else:
            st.info("Negative label not detected reliably for Chart 4.")

    # Chart 5: Sankey-like flow between two categorical columns (role and zone/state if available)
    st.subheader("Category flow (role -> another categorical)")
    other_cat = None
    for c in df_chart.select_dtypes(include=['object','category']).columns:
        if c not in [role_col, target_col]:
            other_cat = c; break
    if other_cat:
        # prepare sankey source-target counts (use top categories to keep plot readable)
        temp = df_chart[[role_col, other_cat]].dropna()
        top_left = temp[role_col].value_counts().nlargest(8).index.tolist()
        top_right = temp[other_cat].value_counts().nlargest(8).index.tolist()
        temp = temp[temp[role_col].isin(top_left) & temp[other_cat].isin(top_right)]
        flow = temp.groupby([role_col, other_cat]).size().reset_index(name='count')
        # build sankey
        labels = list(pd.Index(flow[role_col].tolist() + flow[other_cat].tolist()).unique())
        source = flow[role_col].apply(lambda x: labels.index(x)).tolist()
        target = flow[other_cat].apply(lambda x: labels.index(x)).tolist()
        fig5 = go.Figure(data=[go.Sankey(node=dict(label=labels, pad=15), link=dict(source=source, target=target, value=flow['count'].tolist()))])
        fig5.update_layout(title_text=f"Sankey: {role_col} -> {other_cat}", height=400)
        st.plotly_chart(fig5, use_container_width=True)
        st.markdown("**Insight:** Visualize flows to spot clusters or problematic transitions between categories.")
    else:
        st.info("Not enough categorical columns for Sankey chart.")

with tab2:
    st.header("Train Models (DT, RF, GBRT)")
    st.write("This tab trains the three models using stratified 5-fold CV for training confusion matrices and evaluates on a held-out 30% test set.")
    if st.button("Run Training & Evaluation"):
        with st.spinner("Preprocessing and training..."):
            preprocessor, X, y, numeric_cols, cat_cols = preprocess_for_model(df, target_col)
            results, label_encoder = train_and_evaluate(X, y, preprocessor)
        st.success("Training complete. Metrics and plots below.")

        # Metrics table
        metrics_rows = []
        for name, res in results.items():
            m = res['metrics']
            metrics_rows.append({'Algorithm': name, 'Train Accuracy (cv-oof)': m['train_acc_cv'], 'Test Accuracy': m['test_acc'],
                                 'Precision': m['precision'], 'Recall': m['recall'], 'F1-score': m['f1'], 'AUC': m['auc']})
        metrics_df = pd.DataFrame(metrics_rows).set_index('Algorithm')
        st.subheader("Metrics Table")
        st.dataframe(metrics_df.style.format("{:.4f}"))

        # Confusion matrices: training (CV) and testing
        st.subheader("Confusion Matrices (Training - CV OOF)")
        cols_plot = st.columns(len(results))
        for i,(name,res) in enumerate(results.items()):
            with cols_plot[i]:
                cm = confusion_matrix(res['y_train'], res['y_train_pred_cv'])
                st.write(f"**{name} (train CV)**")
                plot_confusion(cm, res['class_names'], title=f"{name} - Train (CV)")
        st.subheader("Confusion Matrices (Test)")
        cols_plot = st.columns(len(results))
        for i,(name,res) in enumerate(results.items()):
            with cols_plot[i]:
                cm = confusion_matrix(res['y_test'], res['y_test_pred'])
                st.write(f"**{name} (test)**")
                plot_confusion(cm, res['class_names'], title=f"{name} - Test", cmap='Greens')

        # ROC plot
        st.subheader("ROC Curves (Test Set)")
        plot_roc_multi(results)

        # Feature importances
        st.subheader("Feature Importances (Top features)")
        feature_names = (numeric_cols + cat_cols)
        fi = get_feature_importances(results, feature_names)
        for name, series in fi.items():
            st.markdown(f"**{name}**")
            if series is None:
                st.write("No feature_importances_ available for this model.")
            else:
                st.bar_chart(series.head(15))

        # Save pipelines to session state for prediction tab
        st.session_state['models_results'] = results
        st.session_state['label_encoder'] = label_encoder

with tab3:
    st.header("Upload New Data & Predict")
    st.write("Upload a new CSV (same schema) and get predictions from trained models. You can then download the data with predicted label column appended.")

    uploaded_new = st.file_uploader("Upload new CSV for prediction", type=['csv'], key="predict_uploader")
    if uploaded_new is not None:
        new_df = pd.read_csv(uploaded_new)
        st.write("Preview of uploaded data:")
        st.dataframe(new_df.head())

        if 'models_results' not in st.session_state:
            st.info("No trained models in session. Go to 'Train Models' tab and click Run Training first.")
        else:
            chosen_model = st.selectbox("Choose model for prediction", options=list(st.session_state['models_results'].keys()))
            if st.button("Predict and Download"):
                res = st.session_state['models_results'][chosen_model]
                pipeline = res['pipeline']
                # ensure preprocessor and pipeline are present; predict
                try:
                    preds = pipeline.predict(new_df)
                    labels = st.session_state['label_encoder'].inverse_transform(preds)
                    out = new_df.copy()
                    out['PRED_'+target_col] = labels
                    st.write("Predictions preview:")
                    st.dataframe(out.head())
                    href = download_link(out, filename="predictions_with_label.csv")
                    st.markdown(href, unsafe_allow_html=True)
                except Exception as e:
                    st.error(f"Prediction failed: {e}")

st.markdown("---")
st.markdown("**Notes:**\n- The app attempts safe, conservative preprocessing for tree models (median imputation, ordinal encoding). "
            "\n- If your dataset schema differs significantly, choose appropriate columns from the sidebar (target, role, satisfaction). "
            "\n- For production deployment, perform careful hyperparameter tuning and proper feature engineering.")
